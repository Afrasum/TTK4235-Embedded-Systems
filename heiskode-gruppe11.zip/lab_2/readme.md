# README

## Gruppe 11

Afras Mansoor, Mina Al-Dolaimi
